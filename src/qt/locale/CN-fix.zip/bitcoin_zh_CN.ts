<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="+14"/>
        <source>About LEOcoin</source>
        <translation>关于 LEOcoin </translation>
    </message>
    <message>
        <location line="+39"/>
        <source>&lt;b&gt;LEOcoin&lt;/b&gt; version</source>
        <translation>&lt;b&gt; LEOcoin &lt;/b&gt; 版本</translation>
    </message>
    <message>
        <location line="+41"/>
        <source>Copyright ? 2013 The LEOcoin developers</source>
        <translation></translation>
    </message>
    <message>
        <source>Copyright © 2013 The LEOcoin developers</source>
        <translation type="obsolete">Copyright © 2013 The LEOcoin developers</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>
This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file COPYING or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>版权归 LEOcoin 开发者所有  © 2013

这是一个实验性软件。

Distributed under the MIT/X11 software license, see the accompanying file license.txt or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="+14"/>
        <source>Address Book</source>
        <translation>地址薄</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>These are your LEOcoin addresses for receiving payments. You may want to give a different one to each sender so you can keep 
track of who is paying you.</source>
        <translation>这些是你接收支付的 LEOcoin 地址。当支付时你可以给出不同的地址，以便追踪不同的支付者。</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Double-click to edit address or label</source>
        <translation>双击以编辑地址或标签</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Create a new address</source>
        <translation>创建新地址</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>复制当前选中地址到系统剪贴板</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Sign a message to prove you own a LEOcoin address</source>
        <translation>发送签名消息以证明您是该元宝币地址的拥有者</translation>
    </message>
    <message>
        <location line="-36"/>
        <source>&amp;New Address</source>
        <translation>&amp;新建地址</translation>
    </message>
    <message>
        <source>These are your LEOcoin addresses for receiving payments. You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation type="obsolete">这些是你接收支付的 LEOcoin 地址。当支付时你可以给出不同的地址，以便追踪不同的支付者。</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Copy Address</source>
        <translation>&amp;复制地址</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Show &amp;QR Code</source>
        <translation>显示二维码</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Sign &amp;Message</source>
        <translation>&amp;发送签名消息</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Verify a message to ensure it was signed with a specified LEOcoin address</source>
        <translation>验证这个消息以确保它已经与一个LEOcoin地址签名</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Delete the currently selected address from the list</source>
        <translation>从列表中删除当前选中地址。只有发送地址可以被删除。</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;验证消息</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>&amp;Delete</source>
        <translation>&amp;删除</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="+65"/>
        <source>Copy &amp;Label</source>
        <translation>复制 &amp;标签</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Edit</source>
        <translation>&amp;编辑</translation>
    </message>
    <message>
        <location line="+250"/>
        <source>Export Address Book Data</source>
        <translation>导出地址薄数据</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>逗号分隔文件 (*.csv)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Error exporting</source>
        <translation>导出错误</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>无法写入文件 %1。</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="+142"/>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>(no label)</source>
        <translation>(没有标签)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="+26"/>
        <source>Passphrase Dialog</source>
        <translation>密码对话框</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Enter passphrase</source>
        <translation>输入口令</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>New passphrase</source>
        <translation>新口令</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Repeat new passphrase</source>
        <translation>重复新口令</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="+33"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>输入钱包的新口令。&lt;br/&gt;使用的口令请至少包含&lt;b&gt;10个以上随机字符&lt;/&gt;，或者是&lt;b&gt;8个以上的单词&lt;/b&gt;。</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Encrypt wallet</source>
        <translation>加密钱包</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>该操作需要您首先使用口令解锁钱包。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unlock wallet</source>
        <translation>解锁钱包</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>该操作需要您首先使用口令解密钱包。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Decrypt wallet</source>
        <translation>解密钱包</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Change passphrase</source>
        <translation>修改口令</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>请输入钱包的旧口令与新口令。</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Confirm wallet encryption</source>
        <translation>确认加密钱包</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR COINS&lt;/b&gt;!</source>
        <translation>警告：如果您加密了您的钱包之后忘记了口令，您将会&lt;b&gt;失去所有的元宝币&lt;/b&gt;！
确定要加密钱包吗？</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>你确认要加密你的钱包吗?</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>LEOcoin will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your coins from being stolen by malware infecting your computer.</source>
        <translation>将关闭软件以完成加密过程。 请您谨记：钱包加密并不是万能的，电脑中毒，您的元宝币还是有可能丢失。</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>重要：之前备份的钱包文件将会被替换为新生成的，加密的钱包文件。出于安全考虑，只要使用新的加密过的钱包，之前未加密的钱包将不再使用。</translation>
    </message>
    <message>
        <location line="+100"/>
        <location line="+24"/>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>警告：大写锁定键CapsLock开启！</translation>
    </message>
    <message>
        <location line="-130"/>
        <location line="+58"/>
        <source>Wallet encrypted</source>
        <translation>钱包已加密</translation>
    </message>
    <message>
        <location line="-43"/>
        <location line="+7"/>
        <location line="+42"/>
        <location line="+6"/>
        <source>Wallet encryption failed</source>
        <translation>钱包加密失败</translation>
    </message>
    <message>
        <location line="-54"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>由于一个本地错误，加密钱包操作已经失败。您的钱包没有被加密。</translation>
    </message>
    <message>
        <location line="+7"/>
        <location line="+48"/>
        <source>The supplied passphrases do not match.</source>
        <translation>口令不匹配。</translation>
    </message>
    <message>
        <location line="-37"/>
        <source>Wallet unlock failed</source>
        <translation>钱包解锁失败</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+11"/>
        <location line="+19"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>用于解密钱包的口令不正确。</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Wallet decryption failed</source>
        <translation>钱包解密失败。</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>钱包口令修改成功</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="+265"/>
        <source>Sign &amp;message...</source>
        <translation>对消息签名...</translation>
    </message>
    <message>
        <location line="+241"/>
        <source>Synchronizing with network...</source>
        <translation>网络同步中...</translation>
    </message>
    <message>
        <location line="-310"/>
        <source>&amp;Overview</source>
        <translation>&amp;概况</translation>
    </message>
    <message>
        <location line="-123"/>
        <source>LEOcoin</source>
        <translation>LEOcoin</translation>
    </message>
    <message>
        <location line="+124"/>
        <source>Show general overview of wallet</source>
        <translation>显示钱包概况</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Mining</source>
        <translation>&amp;挖矿</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Configure mining</source>
        <translation>配置挖矿参数</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Send coins to a LEOcoin address</source>
        <translation>向一个 LEOcoin 地址发送 LEOcoin</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Transactions</source>
        <translation>&amp;交易</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Browse transaction history</source>
        <translation>查看交易历史</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Address Book</source>
        <translation>&amp;地址薄</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>修改存储的地址和标签列表</translation>
    </message>
    <message>
        <location line="-13"/>
        <source>&amp;Receive coins</source>
        <translation>&amp;接收货币</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>显示接收支付的地址列表</translation>
    </message>
    <message>
        <location line="-7"/>
        <source>&amp;Send coins</source>
        <translation>&amp;发送货币</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>E&amp;xit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Quit application</source>
        <translation>退出程序</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Show information about LEOcoin</source>
        <translation>显示 LEOcoin 的相关信息</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>About &amp;Qt</source>
        <translation>关于 &amp;Qt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show information about Qt</source>
        <translation>显示Qt相关信息</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Options...</source>
        <translation>&amp;选项...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Modify configuration options for LEOcoin</source>
        <translation>设置选项</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;加密钱包...</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;备份钱包...</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;修改密码...</translation>
    </message>
    <message>
        <location line="+87"/>
        <location line="+63"/>
        <source>LEOcoin client</source>
        <translation>LEOcoin 客户端</translation>
    </message>
    <message numerus="yes">
        <location line="+69"/>
        <source>%n active connection(s) to LEOcoin network</source>
        <translation>
            <numerusform>
                %n 个到 LEOcoin 网络的活动连接
            </numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+26"/>
        <source>~%n block(s) remaining</source>
        <translation>
            <numerusform>~还剩 %n 个区块</numerusform>
        </translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Downloaded %1 of %2 blocks of transaction history (%3% done).</source>
        <translation>已下载 %2 个交易历史区块中的 %1 个 (完成率 %3% ).</translation>
    </message>
    <message>
        <location line="-246"/>
        <source>&amp;Export...</source>
        <translation>&amp;导出...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Export the data in the current tab to a file</source>
        <translation>导出当前数据到文件</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>加密或解密钱包</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>&amp;About LEOcoin</source>
        <translation>关于 LEOcoin</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Backup wallet to another location</source>
        <translation>备份钱包到其它文件夹</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>修改钱包加密口令</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Debug window</source>
        <translation>&amp;调试窗口</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open debugging and diagnostic console</source>
        <translation>在诊断控制台调试</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>&amp;Verify message...</source>
        <translation>&amp;验证消息...</translation>
    </message>
    <message>
        <location line="-193"/>
        <source>Wallet</source>
        <translation>钱包</translation>
    </message>
    <message>
        <location line="+183"/>
        <source>&amp;Show / Hide</source>
        <translation>&amp;显示 / 隐藏</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>&amp;File</source>
        <translation>&amp;文件</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>&amp;Settings</source>
        <translation>&amp;设置</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Help</source>
        <translation>&amp;帮助</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Tabs toolbar</source>
        <translation>分页工具栏</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Actions toolbar</source>
        <translation>动作工具栏</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+9"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location line="+172"/>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>%1 个交易历史的区块已下载</translation>
    </message>
    <message numerus="yes">
        <location line="+22"/>
        <source>%n second(s) ago</source>
        <translation>
            <numerusform>%n 秒前</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n minute(s) ago</source>
        <translation>
            <numerusform>%n 分钟前</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n hour(s) ago</source>
        <translation>
            <numerusform>%n 小时前</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+4"/>
        <source>%n day(s) ago</source>
        <translation>
            <numerusform>%n 天前</numerusform>
        </translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Up to date</source>
        <translation>最新状态</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Catching up...</source>
        <translation>更新中...</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Last received block was generated %1.</source>
        <translation>最新收到的区块产生于 %1。</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Mining LEOcoins at %1 hashes per second</source>
        <translation>正在以 %1 hashes/s 挖矿</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Not mining LEOcoins</source>
        <translation>没在挖矿</translation>
    </message>
    <message>
        <location line="+51"/>
        <source>This transaction is over the size limit.  You can still send it for a fee of %1, which goes to the nodes that process your transaction and helps to support the network.  Do you want to pay the fee?</source>
        <translation>该笔交易的数据量超限.您可以选择支付 %1 交易费， 交易费将支付给处理该笔交易的网络节点，有助于维持元宝币网络的运行.  您愿意支付交易费用吗？</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm transaction fee</source>
        <translation>确认交易费</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Sent transaction</source>
        <translation>已发送交易</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Incoming transaction</source>
        <translation>流入交易</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>日期: %1
金额: %2
类别: %3
地址: %4
</translation>
    </message>
    <message>
        <location line="+108"/>
        <location line="+15"/>
        <source>URI handling</source>
        <translation>URI处理</translation>
    </message>
    <message>
        <location line="-15"/>
        <location line="+15"/>
        <source>URI can not be parsed! This can be caused by an invalid LEOcoin address or malformed URI parameters.</source>
        <translation>URI不能解析！这可能是由于一个的无效LEOcoin地址或畸形URI参数。</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>钱包已被&lt;b&gt;加密&lt;/b&gt;，当前为&lt;b&gt;解锁&lt;/b&gt;状态</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>钱包已被&lt;b&gt;加密&lt;/b&gt;，当前为&lt;b&gt;锁定&lt;/b&gt;状态</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Confirm wallet encryption</source>
        <translation>确认加密钱包</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: If want to encrypt your wallet, &lt;b&gt;you must stop mining first&lt;/b&gt;!</source>
        <translation>错误: 如果想要加密钱包, &lt;b&gt;请先停止挖矿&lt;/b&gt;!</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Backup Wallet</source>
        <translation>备份钱包</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Wallet Data (*.dat)</source>
        <translation>钱包文件 (*.dat)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Backup Failed</source>
        <translation>备份失败</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>备份钱包到其它文件夹失败.</translation>
    </message>
    <message>
        <location filename="../bitcoin.cpp" line="+109"/>
        <source>A fatal error occurred. LEOcoin can no longer continue safely and will quit.</source>
        <translation>发生致命错误. 元宝币客户端的安全存在问题，将退出.</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <location filename="../clientmodel.cpp" line="+220"/>
        <source>Network Alert</source>
        <translation>网络警报</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="+14"/>
        <source>Edit Address</source>
        <translation>编辑地址</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>&amp;Label</source>
        <translation>&amp;标签</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The label associated with this address book entry</source>
        <translation>与此地址条目关联的标签</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Address</source>
        <translation>&amp;地址</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>该地址与地址簿中的条目已关联，无法作为发送地址编辑。</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="+20"/>
        <source>New receiving address</source>
        <translation>新接收地址</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>New sending address</source>
        <translation>新发送地址</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Edit receiving address</source>
        <translation>编辑接收地址</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Edit sending address</source>
        <translation>编辑发送地址</translation>
    </message>
    <message>
        <location line="+60"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>输入的地址 &quot;%1&quot; 已经存在于地址薄。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The entered address &quot;%1&quot; is not a valid LEOcoin address.</source>
        <translation>您输入的 &quot;%1&quot; 不是合法的元宝币地址.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Could not unlock wallet.</source>
        <translation>无法解锁钱包</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New key generation failed.</source>
        <translation>密钥创建失败.</translation>
    </message>
</context>
<context>
    <name>GUIUtil::HelpMessageBox</name>
    <message>
        <location filename="../guiutil.cpp" line="+419"/>
        <location line="+12"/>
        <source>LEOcoin-Qt</source>
        <translation>LEOcoin-Qt</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>version</source>
        <translation>版本</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Usage:</source>
        <translation>使用：</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>command-line options</source>
        <translation>命令行选项</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>UI options</source>
        <translation>界面选项</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>设置语言, 例如 &quot;de_DE&quot; (缺省: 系统语言)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Start minimized</source>
        <translation>启动时最小化</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>启动时显示版权页 (缺省: 1)</translation>
    </message>
</context>
<context>
    <name>MiningPage</name>
    <message>
        <location filename="../forms/miningpage.ui" line="+14"/>
        <source>Mining</source>
        <translation>挖矿</translation>
    </message>
    <message>
        <location line="+237"/>
        <source>Username</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location line="-10"/>
        <source>Server</source>
        <translation>服务器</translation>
    </message>
    <message>
        <location line="-103"/>
        <source>pool.LEOcoin.com</source>
        <translation>pool.LEOcoin.com</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location line="+26"/>
        <location filename="../miningpage.cpp" line="+414"/>
        <source>Start Mining</source>
        <translation>开始挖矿</translation>
    </message>
    <message>
        <location line="-169"/>
        <source>Scantime</source>
        <translation>扫描时间</translation>
    </message>
    <message>
        <location line="+116"/>
        <source>Threads</source>
        <translation>线程数</translation>
    </message>
    <message>
        <location line="-129"/>
        <source>Debug Logging</source>
        <translation>调试日志输出</translation>
    </message>
    <message>
        <location line="+136"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location line="+80"/>
        <source>Solo Mining</source>
        <translation>单独挖矿</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Pool Mining</source>
        <translation>矿池</translation>
    </message>
    <message>
        <location line="-244"/>
        <source>9332</source>
        <translation>9332</translation>
    </message>
    <message>
        <location filename="../miningpage.cpp" line="-324"/>
        <source>please input the sever address</source>
        <translation>请输入矿池地址</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>use name should not be empty</source>
        <translation>用户名不能为空</translation>
    </message>
    <message>
        <location line="+101"/>
        <source>Share accepted</source>
        <translation>共享被接受</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Share rejected</source>
        <translation>共享被拒绝</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>LONGPOLL detected a new block</source>
        <translation>LONGPOLL 发现一个新的区块</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Miner didn&apos;t start properly. Try checking your settings.</source>
        <translation>挖矿进程启动异常，正在尝试检查你的设置。</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Couldn&apos;t connect. Please check your username and password.</source>
        <translation>连接矿池失败，请检查你的用户名和密码。</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Couldn&apos;t connect. Please check pool server and port.</source>
        <translation>连接矿池失败，请检查矿池地址和端口号。</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Couldn&apos;t communicate with server. Retrying in 30 seconds.</source>
        <translation>与矿池服务器交互失败，30秒后重试。</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Miner failed to start. Make sure you have the minerd executable and libraries in the same directory as LEOcoin-Qt.</source>
        <translation>挖矿进程启动失败。</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Solo mining stopped.</source>
        <translation>单独挖矿已停止</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Miner exited.</source>
        <translation>挖矿进程已退出</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Solo mining started.</source>
        <translation>单独挖矿已启动</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Miner started. You might not see any output for a few minutes.</source>
        <translation>挖矿进程已启动，可能需要一些时间才能有产出</translation>
    </message>
    <message>
        <location line="+157"/>
        <source>Stop Mining</source>
        <translation>停止挖矿</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../forms/optionsdialog.ui" line="+14"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>&amp;Main</source>
        <translation>&amp;主选项</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Optional transaction fee per kB that helps make sure your transactions are processed quickly. Most transactions are 1 kB. Fee 0.0001 recommended.</source>
        <translation>建议支付交易费用，有助于您的交易得到尽快处理.  绝大多数交易的字节数为 1 kB. 建议支付0.0001个元宝币.</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Pay transaction &amp;fee</source>
        <translation>支付交易 &amp;费</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Automatically start LEOcoin after logging in to the system.</source>
        <translation>系统启动后自动运行元宝币客户端软件</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Start LEOcoin on system login</source>
        <translation>启动时&amp;运行</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Detach block and address databases at shutdown. This means they can be moved to another data directory, but it slows down shutdown. The wallet is always detached.</source>
        <translation>在关闭客户端时，分离块和地址数据库。这意味着它们可以被移动到另一个数据目录，但它会延缓关闭程序。钱包始终处于分离状态。</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Detach databases at shutdown</source>
        <translation>&amp;关闭客户端时分离数据库</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Network</source>
        <translation>&amp;网络</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Automatically open the LEOcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>自动打开LEOcoin的客户端使用的端口。这只有当你的路由器支持UPnP并启用。</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Map port using &amp;UPnP</source>
        <translation>启用UPnP端口映射</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Connect to the LEOcoin network through a SOCKS proxy (e.g. when connecting through Tor).</source>
        <translation>通过 SOCKS proxy 连接网络(例如：通过 Tor 连接网络).</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Connect through SOCKS proxy:</source>
        <translation>&amp;通过SOCKS代理连接:</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Proxy &amp;IP:</source>
        <translation>代理服务器 &amp;IP:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>代理服务器的IP地址 (e.g. 127.0.0.1)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Port:</source>
        <translation>&amp;端口:</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>代理服务器端口 (e.g. 9050)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>SOCKS &amp;Version:</source>
        <translation>SOCKS &amp;版本:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>SOCKS version of the proxy (e.g. 5)</source>
        <translation>代理服务器的SOCKS版本 (e.g. 5)</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>&amp;Window</source>
        <translation>&amp;窗口</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>最小化窗口后只显示一个托盘标志</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;最小化到托盘</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>当窗口关闭时程序最小化而不是退出。当使用该选项时，程序只能通过在菜单中选择退出来关闭</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>M&amp;inimize on close</source>
        <translation>单击关闭按钮时&amp;最小化</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>&amp;Display</source>
        <translation>&amp;显示</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>User Interface &amp;language:</source>
        <translation>&amp;语言：</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>The user interface language can be set here. This setting will take effect after restarting LEOcoin.</source>
        <translation>置语言选项。需重启客户端软件才能生效。</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>Whether to show LEOcoin addresses in the transaction list or not.</source>
        <translation>是否在交易清单中显示 LEOcoin 地址</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will only take effect after restarting Bitcoin.</source>
        <translation type="obsolete">设置语言选项。需重启客户端软件才能生效。</translation>
    </message>
    <message>
        <location line="-22"/>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp; LEOcoin 金额单位:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>选择显示及发送元宝币时使用的最小单位</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>在交易清单中&amp;显示元宝币地址</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;OK</source>
        <translation>&amp;确定</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>&amp;Cancel</source>
        <translation>&amp;取消</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Apply</source>
        <translation>&amp;应用</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="+55"/>
        <source>default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location line="+147"/>
        <location line="+9"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location line="-9"/>
        <location line="+9"/>
        <source>This setting will take effect after restarting LEOcoin.</source>
        <translation>重启客户端软件以使设置生效。</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>The supplied proxy address is invalid.</source>
        <translation>所提供的代理服务器地址是无效的。</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="+14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location line="+35"/>
        <location line="+212"/>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the LEOcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>现在显示的消息可能是过期的. 在连接上元宝币网络节点后，您的钱包将自动与网络同步，但是这个过程还没有完成.</translation>
    </message>
    <message>
        <location line="-170"/>
        <source>Balance:</source>
        <translation>余额：</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Stake:</source>
        <translation>股份:</translation>
    </message>
    <message>
        <location line="+84"/>
        <source>Number of transactions:</source>
        <translation>交易笔数：</translation>
    </message>
    <message>
        <location line="-55"/>
        <source>Unconfirmed:</source>
        <translation>未确认的：</translation>
    </message>
    <message>
        <location line="-107"/>
        <source>Wallet</source>
        <translation>钱包</translation>
    </message>
    <message>
        <location line="+136"/>
        <source>Immature:</source>
        <translation>未成熟的:</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Mined balance that has not yet matured</source>
        <translation>Mined balance that has not yet matured</translation>
    </message>
    <message>
        <location line="+63"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;当前交易&lt;/b&gt;</translation>
    </message>
    <message>
        <location line="-147"/>
        <source>Your current balance</source>
        <translation>您的当前余额</translation>
    </message>
    <message>
        <location line="+58"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>尚未确认的交易总额, 未计入当前余额</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Total of coins that was staked, and do not yet count toward the current balance</source>
        <translation>尚未确认的股份交易，尚未计入当前余额</translation>
    </message>
    <message>
        <location line="+75"/>
        <source>Total number of transactions in wallet</source>
        <translation>钱包总交易数量</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="+122"/>
        <location line="+1"/>
        <source>out of sync</source>
        <translation>不同步</translation>
    </message>
    <message>
        <location line="+192"/>
        <source>More Apps...</source>
        <translation>更多应用...</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="+14"/>
        <source>QR Code Dialog</source>
        <translation>二维码对话框</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Request Payment</source>
        <translation>请求付款</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Amount:</source>
        <translation>金额：</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Label:</source>
        <translation>标签：</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Message:</source>
        <translation>消息：</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>&amp;Save As...</source>
        <translation>&amp;另存为</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="+62"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>将 URI 转换成二维码失败.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>The entered amount is invalid, please check.</source>
        <translation>输入的金额是无效的，请检查。</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI 太长, 请试着精简标签/消息的内容.</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Save QR Code</source>
        <translation>保存二维码</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>PNG Images (*.png)</source>
        <translation>PNG图像文件 (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="+46"/>
        <source>Client name</source>
        <translation>客户端名称</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+23"/>
        <location line="+26"/>
        <location line="+23"/>
        <location line="+23"/>
        <location line="+36"/>
        <location line="+53"/>
        <location line="+23"/>
        <location line="+23"/>
        <location filename="../rpcconsole.cpp" line="+348"/>
        <source>N/A</source>
        <translation>不可用</translation>
    </message>
    <message>
        <location line="-217"/>
        <source>Client version</source>
        <translation>客户端版本</translation>
    </message>
    <message>
        <location line="-45"/>
        <source>&amp;Information</source>
        <translation>&amp;信息</translation>
    </message>
    <message>
        <location line="-10"/>
        <source>LEOcoin - Debug window</source>
        <translation>LEOcoin - 调试窗口</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>LEOcoin Core</source>
        <translation>LEOcoin 内核</translation>
    </message>
    <message>
        <location line="+53"/>
        <source>Using OpenSSL version</source>
        <translation>使用OpenSSL的版本</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Startup time</source>
        <translation>启动时间</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Network</source>
        <translation>网络</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Number of connections</source>
        <translation>连接数</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>On testnet</source>
        <translation>当前为 LEOcoin 测试网络</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Block chain</source>
        <translation>区块链</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Current number of blocks</source>
        <translation>当前区块数</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Estimated total blocks</source>
        <translation>预计区块数</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Last block time</source>
        <translation>上一区块时间</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Open the LEOcoin debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>从当前文件夹打开LEOcoin调试日志文件，对于大日志文件，这可能会花费几秒钟。</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Open</source>
        <translation>&amp;打开</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Command-line options</source>
        <translation>命令行设置</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Show the LEOcoin-Qt help message to get a list with possible LEOcoin command-line options.</source>
        <translation>LEOcoin-Qt 帮助信息中包含 LEOcoin 支持的命令行选项</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Show</source>
        <translation>&amp;显示</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>&amp;Console</source>
        <translation>&amp;控制台</translation>
    </message>
    <message>
        <location line="-260"/>
        <source>Build date</source>
        <translation>创建时间</translation>
    </message>
    <message>
        <location line="+200"/>
        <source>Debug log file</source>
        <translation>调试日志文件</translation>
    </message>
    <message>
        <location line="+109"/>
        <source>Clear console</source>
        <translation>清空控制台</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="-33"/>
        <source>Welcome to the LEOcoin RPC console.</source>
        <translation>欢迎来到 RPC 控制台.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>使用上下方向键浏览历史,  &lt;b&gt;Ctrl-L&lt;/b&gt;清除屏幕.</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>使用 &lt;b&gt;help&lt;/b&gt; 命令显示帮助信息.</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="+14"/>
        <location filename="../sendcoinsdialog.cpp" line="+124"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+5"/>
        <location line="+6"/>
        <location line="+5"/>
        <location line="+5"/>
        <source>Send Coins</source>
        <translation>发送货币</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Send to multiple recipients at once</source>
        <translation>一次发送给多个接收者</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Add &amp;Recipient</source>
        <translation>&amp;添加接收人</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Remove all transaction fields</source>
        <translation>移除所有交易项</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear &amp;All</source>
        <translation>清除 &amp;所有</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Balance:</source>
        <translation>余额：</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>123.456 BTC</source>
        <translation>123.456 BTC</translation>
    </message>
    <message>
        <source>123.456 UTC</source>
        <translation type="obsolete">123.456 UTC</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Confirm the send action</source>
        <translation>确认并发送货币</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>S&amp;end</source>
        <translation>&amp;发送</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="-59"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; 到 %2 (%3)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Confirm send coins</source>
        <translation>确认发送货币</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Are you sure you want to send %1?</source>
        <translation>确定您要发送 %1?</translation>
    </message>
    <message>
        <location line="+0"/>
        <source> and </source>
        <translation> 和 </translation>
    </message>
    <message>
        <location line="+23"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>接收者地址不合法，请检查。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount to pay must be larger than 0.</source>
        <translation>支付金额必须大于0。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The amount exceeds your balance.</source>
        <translation>金额超出您的账上余额。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>计入 %1 交易费后的金额超出您的账上余额.</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>发现重复的地址, 每次只能对同一地址发送一次.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: Transaction creation failed.</source>
        <translation>错误: 创建交易失败.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected. This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>错误: 交易被拒绝. 如果您使用的是备份钱包，可能存在两个钱包不同步的情况，另一个钱包中的元宝币已经被使用，但本地的这个钱包尚没有记录。</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="+14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>A&amp;mount:</source>
        <translation>金额</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Pay &amp;To:</source>
        <translation>支付 &amp;到：</translation>
    </message>
    <message>
        <location line="+24"/>
        <location filename="../sendcoinsentry.cpp" line="+25"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>为这个地址输入一个标签，以便将它添加到您的地址簿</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>&amp;Label:</source>
        <translation>&amp;标签：</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to send the payment to  (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</source>
        <translation>付款地址  (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Choose address from address book</source>
        <translation>从地址薄选择地址</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Paste address from clipboard</source>
        <translation>从剪贴板粘贴地址</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Remove this recipient</source>
        <translation>移除此接收者</translation>
    </message>
    <message>
        <source>Enter a LEOcoin address (e.g. 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</source>
        <translation type="obsolete">请输入LEOcoin地址 (例如: 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="+1"/>
        <source>Enter a LEOcoin address (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</source>
        <translation>请输入LEOcoin地址 (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="+14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>签名 - 签名/验证消息</translation>
    </message>
    <message>
        <location line="+13"/>
        <location line="+124"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;对消息签名</translation>
    </message>
    <message>
        <location line="-118"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>您可以用你的地址对消息进行签名，以证明您是该地址的所有人。注意不要对模棱两可的消息签名，以免遭受钓鱼式攻击。请确保消息真实明确的表达了您的意愿。</translation>
    </message>
    <message>
        <source>The address to sign the message with (e.g. 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</source>
        <translation type="obsolete">用来签名的元宝币地址  (例如 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The address to sign the message with (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</source>
        <translation>用来签名的元宝币地址 (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</translation>
    </message>
    <message>
        <location line="+10"/>
        <location line="+203"/>
        <source>Choose an address from the address book</source>
        <translation>从地址簿选择地址</translation>
    </message>
    <message>
        <location line="-193"/>
        <location line="+203"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location line="-193"/>
        <source>Paste address from clipboard</source>
        <translation>从剪贴板粘贴地址</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Enter the message you want to sign here</source>
        <translation>请输入您要发送的签名消息</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>复制当前签名至剪切板</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Sign the message to prove you own this LEOcoin address</source>
        <translation>注册信息证明你拥有这个LEOcoin地址</translation>
    </message>
    <message>
        <location line="+106"/>
        <source>The address the message was signed with (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</source>
        <translation>要确认的这个消息的地址 (e.g. UakV64wuam9Hrd1ec9UVjs3D5dhAec9rYcigJMT42fPWQ4MG5q4fYCsRttKGCoFB1)</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Verify the message to ensure it was signed with the specified LEOcoin address</source>
        <translation>核实这个消息以确保它在LEOcoin的地址中签名验证过</translation>
    </message>
    <message>
        <location line="-129"/>
        <source>Reset all sign message fields</source>
        <translation>清空所有签名消息栏</translation>
    </message>
    <message>
        <location line="+3"/>
        <location line="+146"/>
        <source>Clear &amp;All</source>
        <translation>清除 &amp;所有</translation>
    </message>
    <message>
        <location line="-87"/>
        <location line="+70"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;验证消息</translation>
    </message>
    <message>
        <location line="-64"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>在下方输入签名地址、消息（确保换行、空格、Tab也被正确拷贝）和签名来验证这个消息，为避免man-in-the-middle诈骗，注意不要在签名中读入比验证消息中读入更多的签名信息，</translation>
    </message>
    <message>
        <source>The address the message was signed with (e.g. 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</source>
        <translation type="obsolete">要确认的这个消息的地址 (e.g. 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</translation>
    </message>
    <message>
        <location line="+78"/>
        <source>Reset all verify message fields</source>
        <translation>R清空所有验证消息栏</translation>
    </message>
    <message>
        <source>Enter a LEOcoin address (e.g. 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</source>
        <translation type="obsolete">请输入元宝币地址 (例如: 4Zo1ga6xuKuQ7JV7M9rGDoxdbYwV5zgQJ5)</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="+28"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>单击“发送签名消息&quot;生成签名</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Enter LEOcoin signature</source>
        <translation>输入 LEOcoin 签名</translation>
    </message>
    <message>
        <location line="-4"/>
        <location line="+3"/>
        <source>Enter a LEOcoin address (e.g. Y9H3tANhMroxU4rCre4bkoeDRhHKRSGwsi)</source>
        <translation>输入一个 LEOcoin 地址 (e.g. Y9H3tANhMroxU4rCre4bkoeDRhHKRSGwsi)</translation>
    </message>
    <message>
        <location line="+83"/>
        <location line="+81"/>
        <source>The entered address is invalid.</source>
        <translation>输入的地址是无效的。</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+8"/>
        <location line="+73"/>
        <location line="+8"/>
        <source>Please check the address and try again.</source>
        <translation>请检查地址，然后重试。</translation>
    </message>
    <message>
        <location line="-81"/>
        <location line="+81"/>
        <source>The entered address does not refer to a key.</source>
        <translation>输入的地址没有指向一个秘钥</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>钱包解锁被取消。</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Private key for the entered address is not available.</source>
        <translation>私人密钥输入的地址不可用。</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Message signing failed.</source>
        <translation>消息签名失败。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message signed.</source>
        <translation>签名的消息。</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>The signature could not be decoded.</source>
        <translation>签名不能被解码。</translation>
    </message>
    <message>
        <location line="+0"/>
        <location line="+13"/>
        <source>Please check the signature and try again.</source>
        <translation>请检查签名并重试。</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>The signature did not match the message digest.</source>
        <translation>签名与消息摘要不匹配</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Message verification failed.</source>
        <translation>消息验证失败。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Message verified.</source>
        <translation>消息验证。</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="+19"/>
        <source>Open until %1</source>
        <translation>至 %1 个数据块时开启</translation>
    </message>
    <message numerus="yes">
        <location line="-2"/>
        <source>Open for %n block(s)</source>
        <translation>
            <numerusform>开启 %n 个数据块</numerusform>
        </translation>
    </message>
    <message>
        <location line="+8"/>
        <source>%1/offline</source>
        <translation>%1/离线?</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1/unconfirmed</source>
        <translation>%1/未确认</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 confirmations</source>
        <translation>%1 确认项</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message numerus="yes">
        <location line="+7"/>
        <source>, broadcast through %n node(s)</source>
        <translation>
            <numerusform>通过 %n 节点组广播</numerusform>
        </translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Source</source>
        <translation>源</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Generated</source>
        <translation>生成</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+17"/>
        <source>From</source>
        <translation>从</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+22"/>
        <location line="+58"/>
        <source>To</source>
        <translation>到</translation>
    </message>
    <message>
        <location line="-77"/>
        <location line="+2"/>
        <source>own address</source>
        <translation>自己的地址</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location line="+37"/>
        <location line="+12"/>
        <location line="+45"/>
        <location line="+17"/>
        <location line="+31"/>
        <source>Credit</source>
        <translation>到帐</translation>
    </message>
    <message numerus="yes">
        <location line="-103"/>
        <source>matures in %n more block(s)</source>
        <translation>
            <numerusform>成熟于 %n 以上数据块</numerusform>
        </translation>
    </message>
    <message>
        <location line="+2"/>
        <source>not accepted</source>
        <translation>未接受</translation>
    </message>
    <message>
        <location line="+44"/>
        <location line="+8"/>
        <location line="+15"/>
        <location line="+31"/>
        <source>Debit</source>
        <translation>支出</translation>
    </message>
    <message>
        <location line="-40"/>
        <source>Transaction fee</source>
        <translation>交易费</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Net amount</source>
        <translation>网络金额</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Message</source>
        <translation>消息</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Comment</source>
        <translation>备注</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Transaction ID</source>
        <translation>交易ID</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated coins must mature 520 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to &quot;not accepted&quot; and it won&apos;t be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>新产生的元宝币必须等待520个数据块之后才能被使用. 当您生产出此数据块,它将被广播至元宝币网络并添加至数据链. 如果添加到数据链失败, 它的状态将变成&quot;不被接受&quot;，产生的元宝币将不能使用. 在您生产新数据块的几秒钟内, 如果其它节点也生产出同样的数据块，有可能会发生这种情况.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Staked coins must wait 520 blocks before they can return to balance and be spent.  When you generated this proof-of-stake block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be a valid stake.  This may occasionally happen if another node generates a proof-of-stake block within a few seconds of yours.</source>
        <translation>新产生的元宝币必须等待520个数据块之后才能被使用. 当您生产出此数据块,它将被广播至元宝币网络并添加至数据链. 如果添加到数据链失败, 它的状态将变成&quot;不被接受&quot;，生产的元宝币将不能使用. 在您生产新数据块的几秒钟内, 如果其它节点也生产出同样的数据块，有可能会发生这种情况.</translation>
    </message>
    <message>
        <source>Staked coins must wait 520 blocks before they can return to balance and be spent.  When you generated this proof-of-stake block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to \&quot;not accepted\&quot; and not be a valid stake.  This may occasionally happen if another node generates a proof-of-stake block within a few seconds of yours.</source>
        <translation type="obsolete">股份币必须等待520个block产生后才能计算入余额和花费。生成这个股份证明机制的block时候，它会被广播到网络并被添加到block链中。如果失败，会成为\&quot;未被接受的\&quot;而且是不可用的股份。 如果另一个节点产生的股份证明机制的block比你提前几秒，这种情况就会偶然发生。</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Debug information</source>
        <translation>调试信息</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Transaction</source>
        <translation>交易</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Inputs</source>
        <translation>输入</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Amount</source>
        <translation>数量</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>true</source>
        <translation>true</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>false</source>
        <translation>false</translation>
    </message>
    <message>
        <location line="-212"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, 未被成功广播</translation>
    </message>
    <message>
        <location line="+35"/>
        <source>unknown</source>
        <translation>未知的</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="+14"/>
        <source>Transaction details</source>
        <translation>交易细节</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>当前面板显示了交易的详细描述</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="+226"/>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Amount</source>
        <translation>数量</translation>
    </message>
    <message numerus="yes">
        <location line="+57"/>
        <source>Open for %n block(s)</source>
        <translation>
            <numerusform>开启 %n 个数据块</numerusform>
        </translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open until %1</source>
        <translation>至 %1 个数据块时开启</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Offline (%1 confirmations)</source>
        <translation>离线 (%1 个确认项)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>未确认 (%1 / %2 条确认信息)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>已确认 (%1 条确认信息)</translation>
    </message>
    <message numerus="yes">
        <location line="+8"/>
        <source>Mined balance will be available when it matures in %n more block(s)</source>
        <translation>
            <numerusform>挖矿所得将在  %n 个数据块之后可用</numerusform>
        </translation>
    </message>
    <message>
        <location line="+5"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>此区块未被其他节点接收，并可能不被接受！</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Generated but not accepted</source>
        <translation>已生成但未被接受</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>Received with</source>
        <translation>接收于</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Received from</source>
        <translation>收款来自</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sent to</source>
        <translation>发送到</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Payment to yourself</source>
        <translation>付款给自己</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Mined</source>
        <translation>挖矿所得</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>(n/a)</source>
        <translation>(n/a)</translation>
    </message>
    <message>
        <location line="+199"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>交易状态。 鼠标移到此区域上可显示确认消息项的数目。</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Date and time that the transaction was received.</source>
        <translation>接收交易的时间</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type of transaction.</source>
        <translation>交易类别。</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Destination address of transaction.</source>
        <translation>交易目的地址。</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Amount removed from or added to balance.</source>
        <translation>从余额添加或移除的金额</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="+55"/>
        <location line="+16"/>
        <source>All</source>
        <translation>全部</translation>
    </message>
    <message>
        <location line="-15"/>
        <source>Today</source>
        <translation>今天</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This week</source>
        <translation>本周</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This month</source>
        <translation>本月</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last month</source>
        <translation>上月</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>This year</source>
        <translation>今年</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Range...</source>
        <translation>范围...</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Received with</source>
        <translation>接收于</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sent to</source>
        <translation>发送到</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>To yourself</source>
        <translation>到自己</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Mined</source>
        <translation>挖矿所得</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Other</source>
        <translation>其他</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Enter address or label to search</source>
        <translation>输入地址或标签进行搜索</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Min amount</source>
        <translation>最小金额</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Copy address</source>
        <translation>复制地址</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy label</source>
        <translation>复制标签</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Copy amount</source>
        <translation>复制金额</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Edit label</source>
        <translation>编辑标签</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show transaction details</source>
        <translation>显示交易详情</translation>
    </message>
    <message>
        <location line="+142"/>
        <source>Export Transaction Data</source>
        <translation>导出交易数据</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Comma separated file (*.csv)</source>
        <translation>逗号分隔文件(*.csv)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Confirmed</source>
        <translation>已确认</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>日期</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Type</source>
        <translation>类别</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Label</source>
        <translation>标签</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Amount</source>
        <translation>数量</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error exporting</source>
        <translation>导出错误</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Could not write to file %1.</source>
        <translation>无法写入文件 %1。</translation>
    </message>
    <message>
        <location line="+95"/>
        <source>Range:</source>
        <translation>范围：</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>to</source>
        <translation>到</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="+199"/>
        <source>Sending...</source>
        <translation>发送中...</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="+127"/>
        <source>LEOcoin version</source>
        <translation>LEOcoin 版本</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>Usage:</source>
        <translation>使用：</translation>
    </message>
    <message>
        <source>Send command to -server or bitcoind</source>
        <translation type="obsolete">发送命令到服务器或者 bitcoind</translation>
    </message>
    <message>
        <location line="-47"/>
        <source>List commands</source>
        <translation>列出命令</translation>
    </message>
    <message>
        <location line="-13"/>
        <source>Get help for a command</source>
        <translation>获得某条命令的帮助</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Options:</source>
        <translation>选项：</translation>
    </message>
    <message>
        <source>Specify configuration file (default: LEOcoin.conf)</source>
        <translation type="obsolete">指定配置文件 (默认: LEOcoin.conf)</translation>
    </message>
    <message>
        <source>Specify pid file (default: LEOcoind.pid)</source>
        <translation type="obsolete">指定配置文件 (默认为 LEOcoind.pid) </translation>
    </message>
    <message>
        <location line="-25"/>
        <source>Generate coins</source>
        <translation>生成货币</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Don&apos;t generate coins</source>
        <translation>不要生成货币</translation>
    </message>
    <message>
        <location line="+64"/>
        <source>Specify data directory</source>
        <translation>指定数据目录</translation>
    </message>
    <message>
        <location line="-8"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>设置数据库缓冲区大小 (缺省: 25MB)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set database disk log size in megabytes (default: 100)</source>
        <translation>设置数据库磁盘日志大小 (缺省: 100MB)</translation>
    </message>
    <message>
        <location line="-28"/>
        <source>Listen for connections on &lt;port&gt; (default: 7777 or testnet: 17777)</source>
        <translation>监听端口连接 &lt;port&gt; (缺省: 8333 or testnet: 18333)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>最大连接数 &lt;n&gt;  (缺省: 125)</translation>
    </message>
    <message>
        <location line="-35"/>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>连接一个节点并获取对端地址, 然后断开连接</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>Specify your own public address</source>
        <translation>指定您的公共地址</translation>
    </message>
    <message>
        <location line="-77"/>
        <source>Bind to given address. Use [host]:port notation for IPv6</source>
        <translation>绑定指定地址. IPv6 使用 [host]:port </translation>
    </message>
    <message>
        <location line="+79"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>拒绝行为不当的节点连接的最大数 (默认: 100)</translation>
    </message>
    <message>
        <location line="-111"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>拒绝行为不当的节点重新连接的秒数 (默认: 86400)</translation>
    </message>
    <message>
        <location line="-27"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv4: %s</source>
        <translation>RPC端口 %u 监听错误</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Cannot obtain a lock on data directory %s.  LEOcoin is probably already running.</source>
        <translation>获取锁文件失败 %s。LEOcoin可能正在运行</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Detach block and address databases. Increases shutdown time (default: 0)</source>
        <translation>分离区块数据库和地址数据库. 会延升关闭时间 (缺省: 0)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>错误: 交易被拒绝. 如果您使用的是备份钱包，可能存在两个钱包不同步的情况，另一个钱包中的元宝币已经被使用，但本地的这个钱包尚没有记录。</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds  </source>
        <translation>错误: 该交易需支付到少 %s 的交易费，原因可能是该交易数量太小、构成太复杂或者使用了新近接收到的元宝币</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Error: Wallet unlocked for block minting only, unable to create transaction.</source>
        <translation>错误：未加锁的钱包只能挖矿，不能创建交易。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 44101 or testnet: 44201)</source>
        <translation>JSON-RPC连接监听&lt;端口&gt; (默认为 8332)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Unable to bind to %s on this computer. LEOcoin is probably already running.</source>
        <translation>绑定到 %s 失败。 LEOcoin可能已经在运行。</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct! If your clock is wrong LEOcoin will not work properly.</source>
        <translation>警告：请检查你的电脑日期和时间是否正确！如果不正确，LEOcoin将不能正常工作。</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>接受命令行和 JSON-RPC 命令</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Error: Transaction creation failed  </source>
        <translation>错误: 创建交易失败</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Error: Wallet locked, unable to create transaction  </source>
        <translation>错误: 钱包被锁，无法创建新的交易</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Importing blockchain data file.</source>
        <translation>正在导入数据链文件</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Importing bootstrap blockchain data file.</source>
        <translation>正在导入引导数据链文件</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>在后台运行并接受命令</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Use the test network</source>
        <translation>使用测试网络</translation>
    </message>
    <message>
        <location line="-96"/>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>A接受来自外部的连接 (缺省: 1 if no -proxy or -connect)</translation>
    </message>
    <message>
        <location line="-52"/>
        <source>An error occurred while setting up the RPC port %u for listening on IPv6, falling back to IPv4: %s</source>
        <translation>IPV6上RPC端口 %u 监听错误，尝试使用IPV4：%s</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Error initializing database environment %s! To recover, BACKUP THAT DIRECTORY, then remove everything from it except for wallet.dat.</source>
        <translation>初始化数据库错误 %s！备份那个文件夹，然后移除除钱包文件之外的其他文件来恢复。</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: 27000)</source>
        <translation>设置 high-priority/low-fee 交易的最大字节数(默认: 27000)</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>警告: -paytxfee 交易费用设得有点高. 每当您发送一笔交易，将会向网络支付这么多的交易费.</translation>
    </message>
    <message>
        <source>Warning: Displayed transactions may not be correct! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation type="obsolete">警告: 显示的交易可能不正确！你需要更新，或者其他节点需要更新。</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>警告: 读取wallet.dat错误！虽然秘钥读取正确，但是交易数据和地址信息有可能已经丢失或者不正确。</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>警告: wallet.dat 崩溃，数据已被抢救！原 wallet.dat 被备份为 wallet.{timestamp}.bak 在 %s 下；如果你的余额或者交易信息不正确，你应该从备份中恢复。</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>尝试从崩溃的 wallet.dat 中恢复私钥</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Block creation options:</source>
        <translation>Block 生成选项:</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Connect only to the specified node(s)</source>
        <translation>只连接到指定节点</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>探测自己的IP地址 (默认: 1 正在监听并且没有配置 -externalip 时)</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Error loading wallet.dat: Wallet requires newer version of LEOcoin</source>
        <translation>加载 wallet.dat 端口失败：钱包需要更新LEOcoin版本</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>监听任一端口失败。 如果这是你想要的，请使用 -listen=0 参数</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Find peers using DNS lookup (default: 0)</source>
        <translation>通过DNS查找网络上的元宝币节点 (缺省: 0)</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Updating blockchain data file.</source>
        <translation>正在更新数据链文件</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Invalid -tor address: &apos;%s&apos;</source>
        <translation>-tor 地址不正确: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Invalid amount for -reservebalance=&lt;amount&gt;</source>
        <translation> -reservebalance=&lt;amount&gt; 数值不正确</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 5000)</source>
        <translation>每个连接的最大接收缓冲区大小, &lt;n&gt;*1000 字节 (默认: 5000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 1000)</source>
        <translation>每个连接的最大发送缓冲区大小, &lt;n&gt;*1000 字节 (默认: 1000)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>LEOcoin</source>
        <translation>LEOcoin</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Only connect to nodes in network &lt;net&gt; (IPv4, IPv6 or Tor)</source>
        <translation>仅连接在这些网络中的节点 &lt;net&gt; (IPv4, IPv6 or Tor)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Output extra debugging information. Implies all other -debug* options</source>
        <translation>输入额外的调试信息。因为着打开所有的 -debug* 选项</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Output extra network debugging information</source>
        <translation>输出额外的网络调试信息</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Prepend debug output with timestamp</source>
        <translation>为调试输出信息添加时间戳</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>SSL 选项: </translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Select the version of socks proxy to use (4-5, default: 5)</source>
        <translation>选择 socks 代理版本 (socks4 或 socks5, 缺省为socks5)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send command to -server or LEOcoind</source>
        <translation>向 -server 或 LEOcoind发送指令</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>跟踪/调试信息输出到控制台，不输出到debug.log文件</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Send trace/debug info to debugger</source>
        <translation>跟踪/调试信息输出到 调试器debugger</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Set maximum block size in bytes (default: 250000)</source>
        <translation>设置每个block最大字节数 (默认: 250000)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Set minimum block size in bytes (default: 0)</source>
        <translation>设置每个block的最小字节数 (default: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>客户端启动时压缩 debug.log 文件(默认: 1 when no -debug)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Specify configuration file (default: LEOcoin.conf)</source>
        <translation>指定配置文件 (默认：LEOcoin.conf)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Specify connection timeout in milliseconds (default: 5000)</source>
        <translation>指定连接超时时间 (毫秒：5000)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Specify pid file (default: LEOcoind.pid)</source>
        <translation>指定 pid 文件 (默认: LEOcoind.pid)</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to sign checkpoint, wrong checkpointkey?
</source>
        <translation>无法验证检查点，检查点秘钥错误？</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Use UPnP to map the listening port (default: 0)</source>
        <translation>使用 UPnp 映射监听端口(默认: 0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>使用 UPnp 映射监听端口 (默认: 1 when listening)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Use proxy to reach tor hidden services (default: same as -proxy)</source>
        <translation>使用代理 (默认: 与 -proxy 相同)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Username for JSON-RPC connections</source>
        <translation>JSON-RPC连接用户名</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Verifying database integrity...</source>
        <translation>验证数据库完整性...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Wallet needed to be rewritten: restart LEOcoin to complete</source>
        <translation>钱包需要重新被写入：重启LEOcoin以完成操作</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: Disk space is low!</source>
        <translation>警告：磁盘空间不足！</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>注意：此版本已经过时，必须升级！</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat 崩溃，抢救失败</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Password for JSON-RPC connections</source>
        <translation>JSON-RPC连接密码</translation>
    </message>
    <message>
        <location line="-55"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>允许从指定IP接受到的JSON-RPC连接</translation>
    </message>
    <message>
        <location line="+63"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>向IP地址为 &lt;ip&gt; 的节点发送指令 (缺省: 127.0.0.1)</translation>
    </message>
    <message>
        <location line="-98"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>当最佳区块变化时执行命令 (命令行中的 %s 会被替换成区块哈希值)</translation>
    </message>
    <message>
        <location line="+122"/>
        <source>Upgrade wallet to latest format</source>
        <translation>将钱包升级到最新的格式</translation>
    </message>
    <message>
        <location line="-16"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>设置密钥池大小为 &lt;n&gt; (缺省: 100)</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>重新扫描数据链以查找遗漏的交易</translation>
    </message>
    <message>
        <location line="-28"/>
        <source>How many blocks to check at startup (default: 2500, 0 = all)</source>
        <translation>启动时需检查的区块数量 (缺省: 2500, 设置0为检查所有区块)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>How thorough the block verification is (0-6, default: 1)</source>
        <translation>需要几个确认 (0-6个, 缺省: 1个)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Imports blocks from external blk000?.dat file</source>
        <translation>从外来文件 blk000?.dat 导入区块数据</translation>
    </message>
    <message>
        <location line="+55"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>为 JSON-RPC 连接使用 OpenSSL (https)连接</translation>
    </message>
    <message>
        <location line="-22"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>服务器证书 (默认为 server.cert)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Server private key (default: server.pem)</source>
        <translation>服务器私钥 (默认为 server.pem)</translation>
    </message>
    <message>
        <location line="-128"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>可接受的加密器 (默认为 TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</translation>
    </message>
    <message>
        <location line="+140"/>
        <source>This help message</source>
        <translation>该帮助信息</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unable to bind to %s on this computer (bind returned error %d, %s)</source>
        <translation>无法绑定本机端口 %s  (返回错误消息 %d, %s)</translation>
    </message>
    <message>
        <location line="-73"/>
        <source>Connect through socks proxy</source>
        <translation>通过 socks 代理连接</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>使用 -addnode, -seednode 和 -connect选项时允许DNS查找</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Loading addresses...</source>
        <translation>正在加载地址...</translation>
    </message>
    <message>
        <location line="-28"/>
        <source>Error loading blkindex.dat</source>
        <translation>blkindex.dat文件加载错误</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>wallet.dat钱包文件加载错误：钱包损坏</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Error loading wallet.dat</source>
        <translation>wallet.dat钱包文件加载错误</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Invalid -proxy address: &apos;%s&apos;</source>
        <translation>非法的代理地址: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Unknown network specified in -onlynet: &apos;%s&apos;</source>
        <translation>被指定的是未知网络 -onlynet: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-1"/>
        <source>Unknown -socks proxy version requested: %i</source>
        <translation>被指定的是未知socks代理版本: %i</translation>
    </message>
    <message>
        <location line="-79"/>
        <source>Cannot resolve -bind address: &apos;%s&apos;</source>
        <translation>无法解析 -bind 端口地址: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot resolve -externalip address: &apos;%s&apos;</source>
        <translation>无法解析 -externalip 地址: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: &apos;%s&apos;</source>
        <translation>非法金额 -paytxfee=&lt;amount&gt;: &apos;%s&apos;</translation>
    </message>
    <message>
        <location line="-16"/>
        <source>Error: could not start node</source>
        <translation>错误: 无法启动节点</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Sending...</source>
        <translation>发送中</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Invalid amount</source>
        <translation>金额不对</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>Insufficient funds</source>
        <translation>金额不足</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Loading block index...</source>
        <translation>加载区块索引...</translation>
    </message>
    <message>
        <location line="-46"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>添加节点并与其保持连接</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Find peers using internet relay chat (default: 1)</source>
        <translation>通过IRC聊天室查找网络上的元宝币节点 (缺省: 1)</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Fee per KB to add to transactions you send</source>
        <translation>每发送1KB交易所需的费用</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Loading wallet...</source>
        <translation>正在加载钱包...</translation>
    </message>
    <message>
        <location line="-41"/>
        <source>Cannot downgrade wallet</source>
        <translation>无法降级钱包格式</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cannot initialize keypool</source>
        <translation>无法初始化 keypool</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cannot write default address</source>
        <translation>无法写入缺省地址</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Rescanning...</source>
        <translation>正在重新扫描...</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Done loading</source>
        <translation>加载完成</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>To use the %s option</source>
        <translation>使用 %s 选项</translation>
    </message>
    <message>
        <location line="-151"/>
        <source>%s, you must set a rpcpassword in the configuration file:
 %s
It is recommended you use the following random password:
rpcuser=bitcoinrpc
rpcpassword=%s
(you do not need to remember this password)
If the file does not exist, create it with owner-readable-only file permissions.
</source>
        <translation>%s, 您必须在配置文件中加入选项 rpcpassword :
 %s
建议您使用下面的随机密码:
rpcuser=bitcoinrpc
rpcpassword=%s
(您无需记忆该密码)
如果配置文件不存在，请新建，并将文件权限设置为仅允许文件所有者读取.</translation>
    </message>
    <message>
        <location line="+88"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location line="-28"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>您必须在配置文件中加入选项 rpcpassword :
 %s
如果配置文件不存在，请新建，并将文件权限设置为仅允许文件所有者读取.</translation>
    </message>
</context>
</TS>
